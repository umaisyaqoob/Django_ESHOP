from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.views import View

# print(make_password("90901"))
# print(check_password("90901", "pbkdf2_sha256$720000$tg8DxXX7QJdOjikh86uCDw$HaHRdE3cyR0j424Kf7nSiV4NEo+Wcaa4EnKXIFMvwc8="))


# Create your views here.

class Index(View):
    def get(self, request):
         data = {}
         cart = request.session.get("cart")
         if not cart:
             request.session['cart'] = {}

         products = None
         categories = Category.get_all_categories()
         categoryID =   request.GET.get('cat')
         if categoryID:
            products = Product.get_all_products_by_categoryid(categoryID)
         else:
            products = Product.get_all_products()
         data = {}
         data['products'] = products
         data['categories'] = categories
         print(request.session.get("customer_email"))
         return render(request, 'index.html', data)
         
         
      
    def post(self, request):
        # request.session.get("cart").clear()
        product = request.POST.get("product")
      #   print(product)
        remove = request.POST.get("remove")
        cart = request.session.get("cart")
        print(cart)
        if cart:
            quantity =  cart.get(product)
            print(f"quantity {quantity}")
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity-1
                else:
                    cart[product] = quantity+1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1
        request.session['cart'] = cart
        print(cart)
        print(request.session['cart'])
        return redirect("/")
     

   


          


          
